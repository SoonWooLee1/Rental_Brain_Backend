package com.devoops.rentalbrain.common.notice.command.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class NoticeReadDTO {
    private Long noticeId;
}
