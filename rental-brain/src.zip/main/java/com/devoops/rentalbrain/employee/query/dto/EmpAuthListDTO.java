package com.devoops.rentalbrain.employee.query.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class EmpAuthListDTO {
    private Long id;
    private String description;
}
